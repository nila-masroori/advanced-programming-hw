#include "Matrix.h"
#include<iostream>
#include<iomanip>
#include<optional>
#include<fstream>
#include<string>
#include<sstream>
#include<bits/stdc++.h>
std::optional<double> det(Matrix&);
std::optional<Matrix> transpose(Matrix&);
 std::optional<Matrix> inv(Matrix&);
 std::vector<std::vector<double>> getData(const char* filename, bool add_bias=true);
void displayDataset(std::vector <std::vector <double >>row);
size_t findMinNoOfMultiplications(std::vector<Matrix>& v);
void findMinimum(std::vector<size_t> t, size_t& m, size_t& a);
size_t findMinOps(size_t i, size_t j, std::vector<size_t> p, std::vector<std::vector<size_t>>& m);
Matrix findWeights(const char*);
Matrix predict(const char*, Matrix& w, bool disp=false);