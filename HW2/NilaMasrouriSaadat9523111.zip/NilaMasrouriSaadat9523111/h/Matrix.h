#include<vector>
#include <array>
#include<math.h>
#include<iostream>
#include<iomanip>
#include<fstream>
class Matrix
{
    public:
        Matrix(const Matrix& mat);
        Matrix(std::vector<std::vector<double>> data);
        Matrix (std::unique_ptr<std::unique_ptr<double[]>[]>& data1, size_t m, size_t n);// where m and n are the number of rows and columns.
        Matrix (size_t m, size_t n, bool ones=true);
        std::array<size_t,2>getSize();
        double det(); 
        double re_det( int n);
        Matrix inv();
        Matrix T();
        void show();
        Matrix delCol(size_t i);
        Matrix col(size_t i);
        void save(const char*);
        void load(const char*);
        Matrix operator* (const Matrix& mat);
        Matrix operator+ (const Matrix& mat);
        Matrix operator- (const Matrix& mat);
        std::vector<double>& operator[](size_t i);
        std::vector<std::vector<double>> gdata();
        
     private:
        std::array<size_t,2>size;
        std::vector<std::vector<double>> data;
        std::vector<std::vector<double>> getCfactor(size_t p,size_t q);
        std::vector<std::vector<double>> ADJ();
        std::vector<std::vector<double>> INV();
    

};