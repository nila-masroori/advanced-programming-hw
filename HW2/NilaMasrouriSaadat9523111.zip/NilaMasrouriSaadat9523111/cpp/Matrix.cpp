    #include"Matrix.h"

     Matrix::Matrix(const Matrix& mat)//copy constructor
     {
         size=mat.size;
         data=mat.data;
     }
     Matrix::Matrix(std::vector<std::vector<double>> data)
     {
       this->data=data;
       size[0]=data.size();
       size[1]=data[0].size();
        
     }
    Matrix::Matrix (std::unique_ptr<std::unique_ptr<double[]>[]>& data1, size_t m, size_t n)
    {
            //here the data1 is a pointer
            size[0]=m;
            size[1]=n;
            std::vector<std::vector<double>>data(m,std::vector<double>(m,0));
            std::unique_ptr<std::unique_ptr<double[]>[]> data2{std::make_unique<std::unique_ptr<double[]>[]>(m)};
            for (size_t i = 0; i < m; i++)
            data2[i]=std::make_unique<double[]>(n);
            for (size_t i = 0; i < m; i++)
                for (size_t j = 0; j < n; j++)
                    data[i][j]=data1[i][j];//data is the main data we're looking for
            
    }

    Matrix::Matrix (size_t m, size_t n, bool ones)
    {
        std::vector<std::vector<double>>one(m,std::vector<double>(n,1));
        std::vector<std::vector<double>>zeros(m,std::vector<double>(n,0));
        size[0]=m;
        size[1]=n;
        if(ones)
        data=one;
        else
        data=zeros;
    }
      std::array <size_t,2> Matrix::getSize()
      {
          return size;
      }

    double Matrix::det()
{
    double dett{};
    Matrix a{data};
    if(size[0]==2)
            return ((data[0][0] * data[1][1]) - (data[1][0] * data[0][1]));
    for (size_t i = 0; i < size[0]; i++)
    {
        for (size_t j = 0; j < size[1]; j++)
        { 
           Matrix b {Matrix(a.getCfactor(i,j))};
            dett+=pow(-1,i+j)*data[i][j]*b.det();
        }
        
    }
    return dett;
}
    
    std::vector<std::vector<double>> Matrix::getCfactor(size_t p, size_t q)
    {
        std::vector<std::vector<double>>mat(size[0]-1, std::vector<double> (size[1]-1, 0));
        Matrix newmat {Matrix(data).delCol(q)};// omitting one column 
        //omitting one row 
        for (size_t i = 0; i < size[0]-1; i++)
        {
            for (size_t j = 0; j < size[1]-1; j++)
            {
                if(i<p)
                mat[i][j]=newmat.data[i][j];
                else
                mat[i][j]=newmat.data[i+1][j];
                
            }
            
        }
        return mat;
}


std::vector<std::vector<double>> Matrix::ADJ()
//to find adjoint matrix 
{
    std::vector<std::vector<double>> adj(size[0], std::vector<double> (size[1], 0));
    std::vector<std::vector<double>> t(size[0], std::vector<double> (size[1], 0));
    size_t N{size[0]};
    if (N == 1) 
    {
        adj[0][0] = 1; 
        return adj;
    }
    int s {1};
    for (size_t i=0; i<N; i++) {
        for (size_t j=0; j<N; j++) {
            //To get cofactor of M[i][j]
            t=Matrix(data).getCfactor(i, j);
            s = ((i+j)%2==0)? 1: -1; //sign of adj[j][i] positive if sum of row and column indexes is even.
            adj[j][i] = (s)*(Matrix(t).det()); //Interchange rows and columns to get the transpose of the cofactor matrix
        }
    }
    return adj;
}
std::vector<std::vector<double>> Matrix::INV() 
{
    double dett = Matrix(data).det();
    std::vector<std::vector<double>> inv(size[0], std::vector<double> (size[1], 0)); 
    std::vector<std::vector<double>> adj(size[0], std::vector<double> (size[1], 0));
    size_t N{size[0]};
 
    adj=Matrix(data).ADJ();    
    if (dett == 0)
     {
        std::cout<< "can't find its inverse"<<std::endl;
        return inv;
    }
    
    for (size_t i=0; i<N; i++)
     { 
        for (size_t j=0; j<N; j++)
            { 
                 inv[i][j] = adj[i][j]/float(dett);
            }
    }
    return inv;
}
Matrix Matrix::inv()
    {
       return Matrix(Matrix(data).INV());
    }
Matrix Matrix::T()
{
    std::vector<std::vector<double>> mat(size[1],std::vector<double>(size[0],0));
    
    for (size_t j = 0; j < size[1]; j++)
    {
        for (size_t i = 0; i < size[0]; i++)
        {
            mat[j][i]=data[i][j]; 
        }
         
    }
    
    return Matrix(mat);
}

void Matrix::show()
{
    for (size_t i = 0; i < size[0]; i++)
    {
        for (size_t j = 0; j < size[1]; j++)
        {
            std::cout<<std::setw(12)<<data[i][j];
        }
        std::cout<<std::endl;
    }
    
}
Matrix Matrix::delCol(size_t i)
{
    std::vector<std::vector<double>> mat(size[0], std::vector<double> (size[1]-1, 0));
    for (size_t n = 0; n < size[0]; n++)
    {
        for (size_t m = 0; m < size[1]-1; m++)
        {
            if(m<i)
            mat[n][m]=data[n][m];
            else
            mat[n][m]=data[n][m+1];
        }
        
    }
    size[0]=mat.size();
    size[1]=mat[0].size();
    data=mat;
    return Matrix(mat);
    
}
Matrix Matrix::col(size_t i)
{
    std::vector<std::vector<double>> mat(size[0], std::vector<double> (1, 0));
    for (size_t n = 0; n < size[0]; n++)
    {
        for (size_t m = 0; m < size[1]; m++)
        {
            if(m==i)
            mat[n][0]=data[n][m];
        }
        
    }
    return Matrix(mat);
}

void Matrix::save(const char* name)
{
    std::ofstream out(name);
    for (size_t i = 0; i <size[0]; i++)
    {
        for (size_t j = 0; j < size[1]; j++)
        {
            out<<data[i][j]<<",";
        }
       out<<std::endl;
    }
}
void Matrix::load(const char* file) 
{
    std::ifstream fin(file);
 	std::vector<std::vector<double>> vec2;
    vec2.clear();
    std::vector<double> vec1;
	std::string line, word, temp;
    double x{};
    while(!fin.eof())
    { 
        getline(fin, line);
        std::stringstream s(line);
        vec1.clear();
        for (size_t i = 0; i < 7; i++)
        {
            getline(s, word,',');
                
            if(!word.empty())
            {  
                x = std::stod(word);
                vec1.push_back(x);
            }
        }
        vec2.push_back(vec1);    
    }
    fin.close();
	data = vec2;
    size[0] = vec2.size();
    size[1] = vec2[0].size();
}
    
Matrix Matrix::operator* (const Matrix& mat)
{
    std::vector<std::vector<double>>c(size[0],std::vector<double>(mat.size[1],0));
    for (size_t i = 0; i <size[0] ; i++)
    {
        for (size_t n = 0; n < mat.size[1]; n++)
        {
            for (size_t j = 0; j < mat.size[0]; j++)
            {
                 c[i][n]+=data[i][j]*mat.data[j][n];
            }
        }
        
    }
    return Matrix(c);
    
}
Matrix Matrix::operator+ (const Matrix& mat)
{
    std::vector<std::vector<double>>c(size[0],std::vector<double>(size[1],0));
    for (size_t i = 0; i < size[0]; i++)
    {
        for (size_t j = 0; j < size[1]; j++)
        {
            c[i][j]=data[i][j]+mat.data[i][j];
        }
        
    }
    return Matrix(c);
}
Matrix Matrix::operator- (const Matrix& mat)
{
    std::vector<std::vector<double>>c(size[0],std::vector<double>(size[1],0));
    for (size_t i = 0; i < size[0]; i++)
    {
        for (size_t j = 0; j < size[1]; j++)
        {
            c[i][j]=data[i][j]-mat.data[i][j];
        }
        
    }
    return Matrix(c);
}

std::vector<double>& Matrix::operator[](size_t i)
{
    return data[i];
}

std::vector<std::vector<double>> Matrix::gdata()
{
    return data;
}