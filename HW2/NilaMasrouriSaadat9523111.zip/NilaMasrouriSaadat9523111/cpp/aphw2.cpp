 #include"aphw2.h"

std::optional<double> det(Matrix& a)
{
    std::array<size_t,2> size{a.getSize()};
    if(size[0]==size[1])
    {
        return a.det();
    }
    return 0;
    std::cout<<"not an square matrix"<<std::endl;
}
 std::optional<Matrix> inv(Matrix& a)
 {
     return a.inv();
 }
std::optional<Matrix> transpose(Matrix& a)
{
    return a.T();
}
std::vector<std::vector<double>> getData(const char* path, bool add_bias)
{
    std::string ss{};
    std::vector <std::vector <double >> row(234,std::vector <double>(8,0));
    std::ifstream iff(path);// for reading the file
    for (size_t i = 0; i < 234; i++) 
    {   
        std::string line{};
        std::getline(iff, line);
        std::stringstream iff(line);
        for (size_t j= 0; j < 8; j++)
        {
            if(add_bias && j==0)
            {
                row[i][0]=1;// har radif avalin sotoon barabre 1 bzar
                j++;
            }
            if(!add_bias && j==7)
            break;
           std::getline(iff,ss,',');//reading each file and saving it into a string 
           
                if(!ss.empty())
                 row[i][j]=std::stod(ss);//casting the string into double
            
        }
    
    }
    iff.close();
     return row;
}
void displayDataset(std::vector <std::vector <double >>row)
 {
     std::cout<<"bias"<<std::setw(20)<<"class"<<std::setw(20)<<"ta"<<std::setw(20)<<"coding"<<std::setw(20)<<"studying"<<std::setw(20)<<"background"<<std::setw(20)<<"mind"<<std::setw(20)<<"grade"<<std::endl;
      for (size_t i = 0; i < 234; i++)
    {
        std::cout<<std::endl;

        for (size_t j= 0; j < 7; j++)
        {
            std::cout<<row[i][j]<<std::setw(20);
        }
        std::cout<<row[i][7];
    }
    std::cout<<std::endl;
 }
    size_t findMinNoOfMultiplications(std::vector<Matrix>& v)
    {
        std::vector<size_t>p(v.size()+1,0);// p is the vector of the dimensions of the matrixes in v
        std::vector<std::vector<size_t>>m(v.size()+1,std::vector<size_t>(v.size()+1,0));
        
            p[0]=(v[0].getSize())[0];
            for (size_t i = 1; i < v.size(); i++)
            {
                p[i]=(v[i].getSize())[0];
                
            }
            p[v.size()]=(v[v.size()-1].getSize())[1];
            size_t min{findMinOps( 1, v.size(),  p,  m)};
            return min;
    }
 void findMinimum(std::vector<size_t> t, size_t& m, size_t& a)
 {
    m = t[0];
    a = 0;
    for (size_t i = 1; i < t.size(); i++)
    {
        if (t[i] < m){
            m = t[i];
            a = i;
            }
    }
}

size_t findMinOps(size_t i, size_t j, std::vector<size_t> p, std::vector<std::vector<size_t>>& m)
{
    if (i==j)
        return 0;
    if (m[i][j] != 0)
        return m[i][j];
    
    std::vector<size_t> temp{};
    
    for (size_t k = i; k < j; k++)
    {
        temp.push_back(findMinOps(i, k, p, m) + findMinOps(k+1, j, p, m) + p[i-1]*p[k]*p[j]);
    }
    size_t min{}, argmin{};
    findMinimum(temp, min, argmin);
    m[i][j] = min;
    return min;
}
Matrix findWeights(const char* filename)
{
    std::vector<std::vector<double>> data{getData(filename,1)};
    
    size_t size0{data.size()};
    size_t size1{data[0].size()};

    std::vector<std::vector<double>>yy(size0,std::vector<double>(1,0));
    std::vector<std::vector<double>>xx(size0,std::vector<double>(size1-1,0));
    
    for (size_t i = 0; i < size0; i++)
    {
        //extracting the grades from the matrix loaded from the file
        yy[i][0]=data[i][7];//7 is actually equal to size1-1

        for (size_t j = 0; j < size1-1; j++)
        {
            //extracting the students data from the matrix loaded from the file
            xx[i][j]=data[i][j];
        }
        
    }
    Matrix x{Matrix{xx}};
    Matrix y{Matrix{yy}};//matrix y with vector yy , y is the desired grades and outputs
    //calculating the weights using the formula and class functions
   Matrix w{(((x.T())*x).inv())*(x.T())*y};
    return w;

}

Matrix predict(const char* filename, Matrix& w, bool disp)
{
    std::vector<std::vector<double>> data{getData(filename,1)};
    size_t size0{data.size()};
    size_t size1{data[0].size()};
    std::vector<std::vector<double>>yy(size0,std::vector<double>(1,0));
    std::vector<std::vector<double>>xx(size0,std::vector<double>(size1-1,0));

    for (size_t i = 0; i < size0; i++)
    {
        for (size_t j = 0; j < size1-1; j++)
        {
            //extracting the students data from the matrix loaded from the file
            xx[i][j]=data[i][j];
        }
        
    }
    Matrix x{Matrix{xx}};
    //estimated output:
    Matrix y{x*w};// calculatng the outputs with estimated weights
    if(disp)
        {
            std::cout<<"NO"<<std::setw(20)<<"Real Grade"<<std::setw(20)<<"Estimated Grade"<<std::endl;
            for (size_t i = 0; i < 234; i++)
            {
                std::cout<<i+1<<std::setw(20)<<data[i][7]<<std::setw(20)<<y.gdata()[i][0]<<std::endl;
            }
            
        }
    return y;
}

